(function ($) {
 "use strict";
 
	$(".select2_demo_2").select2();
	$(".select2_demo_3").select2({
		placeholder: "Select a state",
		allowClear: true
	});

	
 
})(jQuery); 